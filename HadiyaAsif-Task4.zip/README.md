classical model database 
Step by Step guide 
generate tables  in the following 
offices 
employees
customer
productLine
product
orders
orderdetails
payments
